package com.mycompany.texttospeak;

import android.app.*;
import android.os.*;
import android.speech.tts.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import javax.xml.transform.*;
import android.util.*;
import java.util.*;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener
{	
	EditText et_msg_to_speak;
	Button btn_speak;
	TextToSpeech texttospeech;
	SeekBar seek_bar_pitch,seek_bar_speed;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		et_msg_to_speak=findViewById(R.id.et_msg_to_speak);
		btn_speak=findViewById(R.id.btn_speak);
		seek_bar_pitch=findViewById(R.id.seek_bar_pitch);
		seek_bar_speed=findViewById(R.id.seek_bar_speed);
		
		texttospeech= new TextToSpeech(this,this);
		
		btn_speak.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v){
				
				texttoSpeak();
		}	
		});
    }

	
@Override
	public void onInit(int status)
	
	{
		if (status==TextToSpeech.SUCCESS)
		{
			int result = texttospeech.setLanguage(Locale.US);
			if( result == TextToSpeech.LANG_MISSING_DATA  || result== TextToSpeech.LANG_NOT_SUPPORTED)
			{
				Log.e("Error:","This Language is not supported");
			}
			else
			{
				texttoSpeak();
			}
		} 
}

private void texttoSpeak()

{

	
	Float pitch = (float) seek_bar_pitch.getProgress()/50;
	if (pitch < 0.1) pitch =0.5f;

	Float speed = (float) seek_bar_speed.getProgress()/50;
	if (speed < 0.1) speed =2.5f;
	texttospeech.setPitch(pitch);
	texttospeech.setSpeechRate(speed);

	String text =et_msg_to_speak.getText().toString();
	
	if ("".equals(text))
	{
		text="Please Enter some text to Speak";
	}
	if ( Build.VERSION.SDK_INT >=Build.VERSION_CODES.LOLLIPOP)
	{
		
		texttospeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
	}
	else
	{
		texttospeech.speak(text, TextToSpeech.QUEUE_FLUSH, null);
	}
}
	
	
	
	}

